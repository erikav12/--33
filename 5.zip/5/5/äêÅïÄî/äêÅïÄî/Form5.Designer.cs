﻿
namespace ДИПЛОМ
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form5));
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.списокУчениковToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.добавлениеНовыхДанныхToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.темаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.заданиеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.домашнееЗаданиеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.группаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.студентаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.результатыВыполненияЗаданийУчениковToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.тестToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.конспектыТеорийИЛекцийToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.теорииToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.лекцииToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.temaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.дИПЛОМDataSet = new ДИПЛОМ.ДИПЛОМDataSet();
            this.label5 = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iDtemaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nazvanieDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.opisanieDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.osvoenaTemaDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.zadanieBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label10 = new System.Windows.Forms.Label();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.iDzadanieDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.opisanieDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataSdachiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.reshenieDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.otvetDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.dZBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label14 = new System.Windows.Forms.Label();
            this.maskedTextBox2 = new System.Windows.Forms.MaskedTextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.richTextBox3 = new System.Windows.Forms.RichTextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.iDdzDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.opisanieDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datasdachiDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.otvetDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.spisokKursovBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label18 = new System.Windows.Forms.Label();
            this.maskedTextBox3 = new System.Windows.Forms.MaskedTextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.iDkursDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomerKursaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataPostupleniaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kolvaStudentovDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.temaTableAdapter = new ДИПЛОМ.ДИПЛОМDataSetTableAdapters.TemaTableAdapter();
            this.zadanieTableAdapter = new ДИПЛОМ.ДИПЛОМDataSetTableAdapters.ZadanieTableAdapter();
            this.dZTableAdapter = new ДИПЛОМ.ДИПЛОМDataSetTableAdapters.DZTableAdapter();
            this.spisok_kursovTableAdapter = new ДИПЛОМ.ДИПЛОМDataSetTableAdapters.Spisok_kursovTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.temaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.дИПЛОМDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.zadanieBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dZBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spisokKursovBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(12, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(265, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Содержание программы";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(17, 103);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(460, 411);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Aqua;
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.списокУчениковToolStripMenuItem,
            this.добавлениеНовыхДанныхToolStripMenuItem,
            this.результатыВыполненияЗаданийУчениковToolStripMenuItem,
            this.конспектыТеорийИЛекцийToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1529, 28);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.выходToolStripMenuItem,
            this.оПрограммеToolStripMenuItem});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(62, 24);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("выходToolStripMenuItem.Image")));
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.выходToolStripMenuItem.Text = "Выход";
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("оПрограммеToolStripMenuItem.Image")));
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.оПрограммеToolStripMenuItem.Text = "О программе";
            this.оПрограммеToolStripMenuItem.Click += new System.EventHandler(this.оПрограммеToolStripMenuItem_Click);
            // 
            // списокУчениковToolStripMenuItem
            // 
            this.списокУчениковToolStripMenuItem.Name = "списокУчениковToolStripMenuItem";
            this.списокУчениковToolStripMenuItem.Size = new System.Drawing.Size(147, 24);
            this.списокУчениковToolStripMenuItem.Text = "Список учеников";
            this.списокУчениковToolStripMenuItem.Click += new System.EventHandler(this.списокУчениковToolStripMenuItem_Click);
            // 
            // добавлениеНовыхДанныхToolStripMenuItem
            // 
            this.добавлениеНовыхДанныхToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.темаToolStripMenuItem,
            this.заданиеToolStripMenuItem,
            this.домашнееЗаданиеToolStripMenuItem,
            this.группаToolStripMenuItem,
            this.студентаToolStripMenuItem});
            this.добавлениеНовыхДанныхToolStripMenuItem.Name = "добавлениеНовыхДанныхToolStripMenuItem";
            this.добавлениеНовыхДанныхToolStripMenuItem.Size = new System.Drawing.Size(223, 24);
            this.добавлениеНовыхДанныхToolStripMenuItem.Text = "Добавление новых данных";
            // 
            // темаToolStripMenuItem
            // 
            this.темаToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("темаToolStripMenuItem.Image")));
            this.темаToolStripMenuItem.Name = "темаToolStripMenuItem";
            this.темаToolStripMenuItem.Size = new System.Drawing.Size(233, 26);
            this.темаToolStripMenuItem.Text = "Тема";
            this.темаToolStripMenuItem.Click += new System.EventHandler(this.темаToolStripMenuItem_Click);
            // 
            // заданиеToolStripMenuItem
            // 
            this.заданиеToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("заданиеToolStripMenuItem.Image")));
            this.заданиеToolStripMenuItem.Name = "заданиеToolStripMenuItem";
            this.заданиеToolStripMenuItem.Size = new System.Drawing.Size(233, 26);
            this.заданиеToolStripMenuItem.Text = "Задание";
            this.заданиеToolStripMenuItem.Click += new System.EventHandler(this.заданиеToolStripMenuItem_Click);
            // 
            // домашнееЗаданиеToolStripMenuItem
            // 
            this.домашнееЗаданиеToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("домашнееЗаданиеToolStripMenuItem.Image")));
            this.домашнееЗаданиеToolStripMenuItem.Name = "домашнееЗаданиеToolStripMenuItem";
            this.домашнееЗаданиеToolStripMenuItem.Size = new System.Drawing.Size(233, 26);
            this.домашнееЗаданиеToolStripMenuItem.Text = "Домашнее задание";
            this.домашнееЗаданиеToolStripMenuItem.Click += new System.EventHandler(this.домашнееЗаданиеToolStripMenuItem_Click);
            // 
            // группаToolStripMenuItem
            // 
            this.группаToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("группаToolStripMenuItem.Image")));
            this.группаToolStripMenuItem.Name = "группаToolStripMenuItem";
            this.группаToolStripMenuItem.Size = new System.Drawing.Size(233, 26);
            this.группаToolStripMenuItem.Text = "Группа";
            this.группаToolStripMenuItem.Click += new System.EventHandler(this.группаToolStripMenuItem_Click);
            // 
            // студентаToolStripMenuItem
            // 
            this.студентаToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("студентаToolStripMenuItem.Image")));
            this.студентаToolStripMenuItem.Name = "студентаToolStripMenuItem";
            this.студентаToolStripMenuItem.Size = new System.Drawing.Size(233, 26);
            this.студентаToolStripMenuItem.Text = "Студента";
            this.студентаToolStripMenuItem.Click += new System.EventHandler(this.студентаToolStripMenuItem_Click);
            // 
            // результатыВыполненияЗаданийУчениковToolStripMenuItem
            // 
            this.результатыВыполненияЗаданийУчениковToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.тестToolStripMenuItem});
            this.результатыВыполненияЗаданийУчениковToolStripMenuItem.Name = "результатыВыполненияЗаданийУчениковToolStripMenuItem";
            this.результатыВыполненияЗаданийУчениковToolStripMenuItem.Size = new System.Drawing.Size(337, 24);
            this.результатыВыполненияЗаданийУчениковToolStripMenuItem.Text = "Результаты выполнения заданий учеников";
            // 
            // тестToolStripMenuItem
            // 
            this.тестToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("тестToolStripMenuItem.Image")));
            this.тестToolStripMenuItem.Name = "тестToolStripMenuItem";
            this.тестToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.тестToolStripMenuItem.Text = "Тест";
            this.тестToolStripMenuItem.Click += new System.EventHandler(this.тестToolStripMenuItem_Click);
            // 
            // конспектыТеорийИЛекцийToolStripMenuItem
            // 
            this.конспектыТеорийИЛекцийToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.теорииToolStripMenuItem,
            this.лекцииToolStripMenuItem});
            this.конспектыТеорийИЛекцийToolStripMenuItem.Name = "конспектыТеорийИЛекцийToolStripMenuItem";
            this.конспектыТеорийИЛекцийToolStripMenuItem.Size = new System.Drawing.Size(233, 24);
            this.конспектыТеорийИЛекцийToolStripMenuItem.Text = "Конспекты теорий и заданий";
            // 
            // теорииToolStripMenuItem
            // 
            this.теорииToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("теорииToolStripMenuItem.Image")));
            this.теорииToolStripMenuItem.Name = "теорииToolStripMenuItem";
            this.теорииToolStripMenuItem.Size = new System.Drawing.Size(152, 26);
            this.теорииToolStripMenuItem.Text = "Теории";
            this.теорииToolStripMenuItem.Click += new System.EventHandler(this.теорииToolStripMenuItem_Click);
            // 
            // лекцииToolStripMenuItem
            // 
            this.лекцииToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("лекцииToolStripMenuItem.Image")));
            this.лекцииToolStripMenuItem.Name = "лекцииToolStripMenuItem";
            this.лекцииToolStripMenuItem.Size = new System.Drawing.Size(152, 26);
            this.лекцииToolStripMenuItem.Text = "Задания";
            this.лекцииToolStripMenuItem.Click += new System.EventHandler(this.лекцииToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.panel1.Controls.Add(this.tabControl1);
            this.panel1.Location = new System.Drawing.Point(534, 50);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(983, 464);
            this.panel1.TabIndex = 4;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tabControl1.Location = new System.Drawing.Point(13, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(967, 449);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.tabPage1.Controls.Add(this.checkBox1);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.richTextBox1);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.textBox1);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Controls.Add(this.comboBox1);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(959, 420);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Описание";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.temaBindingSource, "Osvoena tema", true));
            this.checkBox1.Location = new System.Drawing.Point(556, 270);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(18, 17);
            this.checkBox1.TabIndex = 9;
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // temaBindingSource
            // 
            this.temaBindingSource.DataMember = "Tema";
            this.temaBindingSource.DataSource = this.дИПЛОМDataSet;
            // 
            // дИПЛОМDataSet
            // 
            this.дИПЛОМDataSet.DataSetName = "ДИПЛОМDataSet";
            this.дИПЛОМDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(419, 270);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(119, 18);
            this.label5.TabIndex = 8;
            this.label5.Text = "Освоена тема";
            // 
            // richTextBox1
            // 
            this.richTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.temaBindingSource, "Opisanie", true));
            this.richTextBox1.Location = new System.Drawing.Point(556, 93);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(397, 130);
            this.richTextBox1.TabIndex = 7;
            this.richTextBox1.Text = "";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(454, 93);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 18);
            this.label4.TabIndex = 6;
            this.label4.Text = "Описание";
            // 
            // textBox1
            // 
            this.textBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.temaBindingSource, "Nazvanie", true));
            this.textBox1.Location = new System.Drawing.Point(556, 30);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(397, 22);
            this.textBox1.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(490, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 18);
            this.label2.TabIndex = 4;
            this.label2.Text = "Тема";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDtemaDataGridViewTextBoxColumn,
            this.nazvanieDataGridViewTextBoxColumn,
            this.opisanieDataGridViewTextBoxColumn,
            this.osvoenaTemaDataGridViewCheckBoxColumn});
            this.dataGridView1.DataSource = this.temaBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(9, 93);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(409, 150);
            this.dataGridView1.TabIndex = 3;
            // 
            // iDtemaDataGridViewTextBoxColumn
            // 
            this.iDtemaDataGridViewTextBoxColumn.DataPropertyName = "ID_tema";
            this.iDtemaDataGridViewTextBoxColumn.HeaderText = "ID_tema";
            this.iDtemaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.iDtemaDataGridViewTextBoxColumn.Name = "iDtemaDataGridViewTextBoxColumn";
            this.iDtemaDataGridViewTextBoxColumn.Width = 125;
            // 
            // nazvanieDataGridViewTextBoxColumn
            // 
            this.nazvanieDataGridViewTextBoxColumn.DataPropertyName = "Nazvanie";
            this.nazvanieDataGridViewTextBoxColumn.HeaderText = "Nazvanie";
            this.nazvanieDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.nazvanieDataGridViewTextBoxColumn.Name = "nazvanieDataGridViewTextBoxColumn";
            this.nazvanieDataGridViewTextBoxColumn.Width = 125;
            // 
            // opisanieDataGridViewTextBoxColumn
            // 
            this.opisanieDataGridViewTextBoxColumn.DataPropertyName = "Opisanie";
            this.opisanieDataGridViewTextBoxColumn.HeaderText = "Opisanie";
            this.opisanieDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.opisanieDataGridViewTextBoxColumn.Name = "opisanieDataGridViewTextBoxColumn";
            this.opisanieDataGridViewTextBoxColumn.Width = 125;
            // 
            // osvoenaTemaDataGridViewCheckBoxColumn
            // 
            this.osvoenaTemaDataGridViewCheckBoxColumn.DataPropertyName = "Osvoena tema";
            this.osvoenaTemaDataGridViewCheckBoxColumn.HeaderText = "Osvoena tema";
            this.osvoenaTemaDataGridViewCheckBoxColumn.MinimumWidth = 6;
            this.osvoenaTemaDataGridViewCheckBoxColumn.Name = "osvoenaTemaDataGridViewCheckBoxColumn";
            this.osvoenaTemaDataGridViewCheckBoxColumn.Width = 125;
            // 
            // comboBox1
            // 
            this.comboBox1.DataSource = this.temaBindingSource;
            this.comboBox1.DisplayMember = "Nazvanie";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(150, 25);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(258, 24);
            this.comboBox1.TabIndex = 2;
            this.comboBox1.ValueMember = "ID_tema";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(6, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 18);
            this.label3.TabIndex = 1;
            this.label3.Text = "Выберите тему";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.tabPage2.Controls.Add(this.textBox3);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.richTextBox2);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.maskedTextBox1);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.textBox2);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.comboBox2);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.dataGridView2);
            this.tabPage2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(959, 420);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Задание";
            // 
            // textBox3
            // 
            this.textBox3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.zadanieBindingSource, "Otvet", true));
            this.textBox3.Location = new System.Drawing.Point(566, 351);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(387, 22);
            this.textBox3.TabIndex = 12;
            // 
            // zadanieBindingSource
            // 
            this.zadanieBindingSource.DataMember = "Zadanie";
            this.zadanieBindingSource.DataSource = this.дИПЛОМDataSet;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(494, 351);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(55, 18);
            this.label10.TabIndex = 11;
            this.label10.Text = "Ответ";
            // 
            // richTextBox2
            // 
            this.richTextBox2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.zadanieBindingSource, "Reshenie", true));
            this.richTextBox2.Location = new System.Drawing.Point(566, 172);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(387, 130);
            this.richTextBox2.TabIndex = 10;
            this.richTextBox2.Text = "";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(473, 173);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(76, 18);
            this.label9.TabIndex = 9;
            this.label9.Text = "Решение";
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.zadanieBindingSource, "Data sdachi", true));
            this.maskedTextBox1.Location = new System.Drawing.Point(566, 99);
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(387, 22);
            this.maskedTextBox1.TabIndex = 8;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(451, 99);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(98, 18);
            this.label8.TabIndex = 7;
            this.label8.Text = "Дата сдачи";
            // 
            // textBox2
            // 
            this.textBox2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.temaBindingSource, "Nazvanie", true));
            this.textBox2.Location = new System.Drawing.Point(566, 26);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(387, 22);
            this.textBox2.TabIndex = 6;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(475, 27);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(74, 18);
            this.label7.TabIndex = 5;
            this.label7.Text = "Задание";
            // 
            // comboBox2
            // 
            this.comboBox2.DataSource = this.zadanieBindingSource;
            this.comboBox2.DisplayMember = "Opisanie";
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(166, 25);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(258, 24);
            this.comboBox2.TabIndex = 3;
            this.comboBox2.ValueMember = "ID_zadanie";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(6, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(154, 18);
            this.label6.TabIndex = 2;
            this.label6.Text = "Выберите задание";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDzadanieDataGridViewTextBoxColumn,
            this.opisanieDataGridViewTextBoxColumn1,
            this.dataSdachiDataGridViewTextBoxColumn,
            this.reshenieDataGridViewTextBoxColumn,
            this.otvetDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.zadanieBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(6, 81);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(418, 150);
            this.dataGridView2.TabIndex = 0;
            // 
            // iDzadanieDataGridViewTextBoxColumn
            // 
            this.iDzadanieDataGridViewTextBoxColumn.DataPropertyName = "ID_zadanie";
            this.iDzadanieDataGridViewTextBoxColumn.HeaderText = "ID_zadanie";
            this.iDzadanieDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.iDzadanieDataGridViewTextBoxColumn.Name = "iDzadanieDataGridViewTextBoxColumn";
            this.iDzadanieDataGridViewTextBoxColumn.Width = 125;
            // 
            // opisanieDataGridViewTextBoxColumn1
            // 
            this.opisanieDataGridViewTextBoxColumn1.DataPropertyName = "Opisanie";
            this.opisanieDataGridViewTextBoxColumn1.HeaderText = "Opisanie";
            this.opisanieDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.opisanieDataGridViewTextBoxColumn1.Name = "opisanieDataGridViewTextBoxColumn1";
            this.opisanieDataGridViewTextBoxColumn1.Width = 125;
            // 
            // dataSdachiDataGridViewTextBoxColumn
            // 
            this.dataSdachiDataGridViewTextBoxColumn.DataPropertyName = "Data sdachi";
            this.dataSdachiDataGridViewTextBoxColumn.HeaderText = "Data sdachi";
            this.dataSdachiDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.dataSdachiDataGridViewTextBoxColumn.Name = "dataSdachiDataGridViewTextBoxColumn";
            this.dataSdachiDataGridViewTextBoxColumn.Width = 125;
            // 
            // reshenieDataGridViewTextBoxColumn
            // 
            this.reshenieDataGridViewTextBoxColumn.DataPropertyName = "Reshenie";
            this.reshenieDataGridViewTextBoxColumn.HeaderText = "Reshenie";
            this.reshenieDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.reshenieDataGridViewTextBoxColumn.Name = "reshenieDataGridViewTextBoxColumn";
            this.reshenieDataGridViewTextBoxColumn.Width = 125;
            // 
            // otvetDataGridViewTextBoxColumn
            // 
            this.otvetDataGridViewTextBoxColumn.DataPropertyName = "Otvet";
            this.otvetDataGridViewTextBoxColumn.HeaderText = "Otvet";
            this.otvetDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.otvetDataGridViewTextBoxColumn.Name = "otvetDataGridViewTextBoxColumn";
            this.otvetDataGridViewTextBoxColumn.Width = 125;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.tabPage3.Controls.Add(this.textBox4);
            this.tabPage3.Controls.Add(this.label14);
            this.tabPage3.Controls.Add(this.maskedTextBox2);
            this.tabPage3.Controls.Add(this.label13);
            this.tabPage3.Controls.Add(this.richTextBox3);
            this.tabPage3.Controls.Add(this.label12);
            this.tabPage3.Controls.Add(this.comboBox3);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Controls.Add(this.dataGridView3);
            this.tabPage3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(959, 420);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Домашня работа";
            // 
            // textBox4
            // 
            this.textBox4.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dZBindingSource, "otvet", true));
            this.textBox4.Location = new System.Drawing.Point(620, 264);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(336, 22);
            this.textBox4.TabIndex = 15;
            // 
            // dZBindingSource
            // 
            this.dZBindingSource.DataMember = "DZ";
            this.dZBindingSource.DataSource = this.дИПЛОМDataSet;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.Location = new System.Drawing.Point(559, 264);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(55, 18);
            this.label14.TabIndex = 14;
            this.label14.Text = "Ответ";
            // 
            // maskedTextBox2
            // 
            this.maskedTextBox2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dZBindingSource, "data_sdachi", true));
            this.maskedTextBox2.Location = new System.Drawing.Point(620, 208);
            this.maskedTextBox2.Name = "maskedTextBox2";
            this.maskedTextBox2.Size = new System.Drawing.Size(336, 22);
            this.maskedTextBox2.TabIndex = 13;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.Location = new System.Drawing.Point(516, 208);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(98, 18);
            this.label13.TabIndex = 12;
            this.label13.Text = "Дата сдачи";
            // 
            // richTextBox3
            // 
            this.richTextBox3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dZBindingSource, "Opisanie", true));
            this.richTextBox3.Location = new System.Drawing.Point(620, 40);
            this.richTextBox3.Name = "richTextBox3";
            this.richTextBox3.Size = new System.Drawing.Size(336, 130);
            this.richTextBox3.TabIndex = 11;
            this.richTextBox3.Text = "";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(540, 40);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(74, 18);
            this.label12.TabIndex = 6;
            this.label12.Text = "Задание";
            // 
            // comboBox3
            // 
            this.comboBox3.DataSource = this.dZBindingSource;
            this.comboBox3.DisplayMember = "Opisanie";
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(249, 39);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(258, 24);
            this.comboBox3.TabIndex = 4;
            this.comboBox3.ValueMember = "ID_dz";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(5, 39);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(238, 18);
            this.label11.TabIndex = 3;
            this.label11.Text = "Выберите Домашнюю работу";
            // 
            // dataGridView3
            // 
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDdzDataGridViewTextBoxColumn,
            this.opisanieDataGridViewTextBoxColumn2,
            this.datasdachiDataGridViewTextBoxColumn1,
            this.otvetDataGridViewTextBoxColumn1});
            this.dataGridView3.DataSource = this.dZBindingSource;
            this.dataGridView3.Location = new System.Drawing.Point(3, 112);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowHeadersWidth = 51;
            this.dataGridView3.RowTemplate.Height = 24;
            this.dataGridView3.Size = new System.Drawing.Size(504, 150);
            this.dataGridView3.TabIndex = 0;
            // 
            // iDdzDataGridViewTextBoxColumn
            // 
            this.iDdzDataGridViewTextBoxColumn.DataPropertyName = "ID_dz";
            this.iDdzDataGridViewTextBoxColumn.HeaderText = "ID_dz";
            this.iDdzDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.iDdzDataGridViewTextBoxColumn.Name = "iDdzDataGridViewTextBoxColumn";
            this.iDdzDataGridViewTextBoxColumn.Width = 125;
            // 
            // opisanieDataGridViewTextBoxColumn2
            // 
            this.opisanieDataGridViewTextBoxColumn2.DataPropertyName = "Opisanie";
            this.opisanieDataGridViewTextBoxColumn2.HeaderText = "Opisanie";
            this.opisanieDataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.opisanieDataGridViewTextBoxColumn2.Name = "opisanieDataGridViewTextBoxColumn2";
            this.opisanieDataGridViewTextBoxColumn2.Width = 125;
            // 
            // datasdachiDataGridViewTextBoxColumn1
            // 
            this.datasdachiDataGridViewTextBoxColumn1.DataPropertyName = "data_sdachi";
            this.datasdachiDataGridViewTextBoxColumn1.HeaderText = "data_sdachi";
            this.datasdachiDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.datasdachiDataGridViewTextBoxColumn1.Name = "datasdachiDataGridViewTextBoxColumn1";
            this.datasdachiDataGridViewTextBoxColumn1.Width = 125;
            // 
            // otvetDataGridViewTextBoxColumn1
            // 
            this.otvetDataGridViewTextBoxColumn1.DataPropertyName = "otvet";
            this.otvetDataGridViewTextBoxColumn1.HeaderText = "otvet";
            this.otvetDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.otvetDataGridViewTextBoxColumn1.Name = "otvetDataGridViewTextBoxColumn1";
            this.otvetDataGridViewTextBoxColumn1.Width = 125;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.tabPage4.Controls.Add(this.textBox6);
            this.tabPage4.Controls.Add(this.label18);
            this.tabPage4.Controls.Add(this.maskedTextBox3);
            this.tabPage4.Controls.Add(this.label17);
            this.tabPage4.Controls.Add(this.textBox5);
            this.tabPage4.Controls.Add(this.label16);
            this.tabPage4.Controls.Add(this.comboBox4);
            this.tabPage4.Controls.Add(this.label15);
            this.tabPage4.Controls.Add(this.dataGridView4);
            this.tabPage4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(959, 420);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Группы";
            // 
            // textBox6
            // 
            this.textBox6.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.spisokKursovBindingSource, "Kolva studentov", true));
            this.textBox6.Location = new System.Drawing.Point(605, 253);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(336, 22);
            this.textBox6.TabIndex = 20;
            // 
            // spisokKursovBindingSource
            // 
            this.spisokKursovBindingSource.DataMember = "Spisok kursov";
            this.spisokKursovBindingSource.DataSource = this.дИПЛОМDataSet;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label18.Location = new System.Drawing.Point(402, 253);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(186, 18);
            this.label18.TabIndex = 19;
            this.label18.Text = "Количества студентов";
            // 
            // maskedTextBox3
            // 
            this.maskedTextBox3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.spisokKursovBindingSource, "Data postuplenia", true));
            this.maskedTextBox3.Location = new System.Drawing.Point(605, 128);
            this.maskedTextBox3.Name = "maskedTextBox3";
            this.maskedTextBox3.Size = new System.Drawing.Size(336, 22);
            this.maskedTextBox3.TabIndex = 18;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label17.Location = new System.Drawing.Point(437, 128);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(151, 18);
            this.label17.TabIndex = 17;
            this.label17.Text = "Дата поступления";
            // 
            // textBox5
            // 
            this.textBox5.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.spisokKursovBindingSource, "Nomer kursa", true));
            this.textBox5.Location = new System.Drawing.Point(605, 43);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(336, 22);
            this.textBox5.TabIndex = 16;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label16.Location = new System.Drawing.Point(469, 47);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(119, 18);
            this.label16.TabIndex = 7;
            this.label16.Text = "Номер группы";
            // 
            // comboBox4
            // 
            this.comboBox4.DataSource = this.spisokKursovBindingSource;
            this.comboBox4.DisplayMember = "Nomer kursa";
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(163, 47);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(258, 24);
            this.comboBox4.TabIndex = 5;
            this.comboBox4.ValueMember = "ID_kurs";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label15.Location = new System.Drawing.Point(3, 47);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(140, 18);
            this.label15.TabIndex = 4;
            this.label15.Text = "Выберите группу";
            // 
            // dataGridView4
            // 
            this.dataGridView4.AutoGenerateColumns = false;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDkursDataGridViewTextBoxColumn,
            this.nomerKursaDataGridViewTextBoxColumn,
            this.dataPostupleniaDataGridViewTextBoxColumn,
            this.kolvaStudentovDataGridViewTextBoxColumn});
            this.dataGridView4.DataSource = this.spisokKursovBindingSource;
            this.dataGridView4.Location = new System.Drawing.Point(3, 112);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.RowHeadersWidth = 51;
            this.dataGridView4.RowTemplate.Height = 24;
            this.dataGridView4.Size = new System.Drawing.Size(418, 129);
            this.dataGridView4.TabIndex = 0;
            // 
            // iDkursDataGridViewTextBoxColumn
            // 
            this.iDkursDataGridViewTextBoxColumn.DataPropertyName = "ID_kurs";
            this.iDkursDataGridViewTextBoxColumn.HeaderText = "ID_kurs";
            this.iDkursDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.iDkursDataGridViewTextBoxColumn.Name = "iDkursDataGridViewTextBoxColumn";
            this.iDkursDataGridViewTextBoxColumn.Width = 125;
            // 
            // nomerKursaDataGridViewTextBoxColumn
            // 
            this.nomerKursaDataGridViewTextBoxColumn.DataPropertyName = "Nomer kursa";
            this.nomerKursaDataGridViewTextBoxColumn.HeaderText = "Nomer kursa";
            this.nomerKursaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.nomerKursaDataGridViewTextBoxColumn.Name = "nomerKursaDataGridViewTextBoxColumn";
            this.nomerKursaDataGridViewTextBoxColumn.Width = 125;
            // 
            // dataPostupleniaDataGridViewTextBoxColumn
            // 
            this.dataPostupleniaDataGridViewTextBoxColumn.DataPropertyName = "Data postuplenia";
            this.dataPostupleniaDataGridViewTextBoxColumn.HeaderText = "Data postuplenia";
            this.dataPostupleniaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.dataPostupleniaDataGridViewTextBoxColumn.Name = "dataPostupleniaDataGridViewTextBoxColumn";
            this.dataPostupleniaDataGridViewTextBoxColumn.Width = 125;
            // 
            // kolvaStudentovDataGridViewTextBoxColumn
            // 
            this.kolvaStudentovDataGridViewTextBoxColumn.DataPropertyName = "Kolva studentov";
            this.kolvaStudentovDataGridViewTextBoxColumn.HeaderText = "Kolva studentov";
            this.kolvaStudentovDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.kolvaStudentovDataGridViewTextBoxColumn.Name = "kolvaStudentovDataGridViewTextBoxColumn";
            this.kolvaStudentovDataGridViewTextBoxColumn.Width = 125;
            // 
            // temaTableAdapter
            // 
            this.temaTableAdapter.ClearBeforeFill = true;
            // 
            // zadanieTableAdapter
            // 
            this.zadanieTableAdapter.ClearBeforeFill = true;
            // 
            // dZTableAdapter
            // 
            this.dZTableAdapter.ClearBeforeFill = true;
            // 
            // spisok_kursovTableAdapter
            // 
            this.spisok_kursovTableAdapter.ClearBeforeFill = true;
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(1529, 559);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form5";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Главная форма преподавателя";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form5_FormClosed);
            this.Load += new System.EventHandler(this.Form5_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.temaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.дИПЛОМDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.zadanieBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dZBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spisokKursovBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem списокУчениковToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem добавлениеНовыхДанныхToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem результатыВыполненияЗаданийУчениковToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem конспектыТеорийИЛекцийToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem теорииToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem лекцииToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private ДИПЛОМDataSet дИПЛОМDataSet;
        private System.Windows.Forms.BindingSource temaBindingSource;
        private ДИПЛОМDataSetTableAdapters.TemaTableAdapter temaTableAdapter;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDtemaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nazvanieDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn opisanieDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn osvoenaTemaDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.BindingSource zadanieBindingSource;
        private ДИПЛОМDataSetTableAdapters.ZadanieTableAdapter zadanieTableAdapter;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDzadanieDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn opisanieDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataSdachiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn reshenieDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn otvetDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.BindingSource dZBindingSource;
        private ДИПЛОМDataSetTableAdapters.DZTableAdapter dZTableAdapter;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.RichTextBox richTextBox3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDdzDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn opisanieDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn datasdachiDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn otvetDataGridViewTextBoxColumn1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.MaskedTextBox maskedTextBox2;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.BindingSource spisokKursovBindingSource;
        private ДИПЛОМDataSetTableAdapters.Spisok_kursovTableAdapter spisok_kursovTableAdapter;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.MaskedTextBox maskedTextBox3;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDkursDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomerKursaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataPostupleniaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kolvaStudentovDataGridViewTextBoxColumn;
        private System.Windows.Forms.ToolStripMenuItem темаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem заданиеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem домашнееЗаданиеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem группаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem студентаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem тестToolStripMenuItem;
    }
}